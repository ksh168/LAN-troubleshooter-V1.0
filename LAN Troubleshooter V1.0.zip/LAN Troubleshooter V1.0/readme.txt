Thank You for using LAN Troubleshooter V1.0
Hey user this is Kunal Sharma.
"LAN not working" is a problem we all face on regular basis. 
But somtimes there's just a normal solution to problem that we can do easily. 
So here I present you LAN troubleshooter 1.0 to aid lazy people like you ;) 
so that they don't have to write those commands again and again.

USER Guide:-
1. Double click on program and click yes in prompt screen.
2. Press any key to continue.
3. Sit back and relax while program does it's work.

------------------------------------------------
LAN Troubleshooter V1.0
Kunal Sharma 2nd year EEE
contact: mailkunalsharma99@gmail.com